# 🚀 QUICK START GUIDE

## Step 1: Install Dependencies

```bash
npm install
```

**Dependencies yang akan terinstall:**
- react & react-dom (UI framework)
- zustand (state management)
- dexie & dexie-react-hooks (IndexedDB)
- html5-qrcode (barcode scanner - GUARANTEED WORKING!)
- lucide-react (icons)
- tailwind (styling)
- vite-plugin-pwa (PWA support)

## Step 2: Run Development Server

```bash
npm run dev
```

Aplikasi akan berjalan di: **http://localhost:5173**

⚠️ **PENTING untuk Barcode Scanner:**
- Gunakan **localhost** atau **HTTPS**
- Kamera TIDAK akan jalan di HTTP biasa
- Berikan permission kamera saat diminta

## Step 3: Login

**Default Credentials:**

### Admin (Full Access)
- Username: **Admin**
- PIN: **1234**

### Kasir (Sales Only)  
- Username: **Kasir**
- PIN: **0000**

## Step 4: Test Barcode Scanner

1. Login sebagai Kasir
2. Tap icon **Scanner** (📷)
3. Izinkan akses kamera
4. Arahkan ke barcode
5. Produk otomatis masuk keranjang!

**Test Barcodes (sudah ada di database):**
- `8999909028234` - Panci (Rp 30.000)
- `8992761111111` - Indomie (Rp 3.500)
- `8996001600115` - Aqua (Rp 4.000)

## Step 5: Build untuk Production

```bash
npm run build
```

Hasil build ada di folder `dist/`

## 🎯 Features to Try

### Kasir Page
✅ Scan barcode dengan kamera
✅ Search produk by name/barcode
✅ Add/remove items dari cart
✅ Update quantity
✅ Checkout cash/QRIS
✅ Validasi stok

### Gudang Page
✅ Scan barcode untuk update stok
✅ Tambah stok (masuk)
✅ Kurangi stok (keluar)
✅ Search produk
✅ View stock level

### Riwayat Page
✅ List semua transaksi
✅ Summary harian (total & jumlah)
✅ Detail per transaksi
✅ Info user yang melakukan transaksi

## 🔧 Troubleshooting

### Kamera tidak kebuka?
```
✅ Pastikan pakai localhost atau HTTPS
✅ Berikan permission kamera
✅ Refresh browser
✅ Test di Chrome/Safari
```

### npm install gagal?
```bash
# Clear cache
npm cache clean --force

# Install ulang
rm -rf node_modules package-lock.json
npm install
```

### Port sudah terpakai?
```bash
# Ganti port di vite.config.js
server: {
  port: 3000, // Ganti ke port lain
}
```

## 📱 Install as PWA

### Android
1. Buka di Chrome
2. Menu → "Add to Home screen"

### iOS  
1. Buka di Safari
2. Share → "Add to Home Screen"

### Desktop
1. Klik icon install di address bar
2. Aplikasi terinstall seperti native app

## 🎨 Customize

### Ganti Data Default

Edit `src/db.js`:
```javascript
// Tambah user
await db.users.add({
  username: 'Your Name',
  role: 'admin',
  pin: '1111'
});

// Tambah produk
await db.products.add({
  barcode: '123456789',
  name: 'Product Name',
  price: 10000,
  stock: 50,
  category: 'Category'
});
```

### Ganti Warna Theme

Edit `tailwind.config.js`:
```javascript
colors: {
  primary: {
    600: '#YOUR_HEX_COLOR'
  }
}
```

## 🚀 Deploy

### Netlify (Recommended)
```bash
npm run build
# Upload folder dist/ ke Netlify
```

### Vercel
```bash
npm i -g vercel
vercel
```

### GitHub Pages
```bash
npm run build
# Push folder dist/ ke gh-pages branch
```

---

**READY! Scanner PASTI JALAN! 🎯**

Kalau ada error, cek:
1. Console browser (F12)
2. Permission kamera
3. HTTPS atau localhost
4. README.md untuk detail

**Happy Coding! 🎉**
