import { useEffect } from 'react';
import { Layers, Package, Receipt, LogOut } from 'lucide-react';
import { useStore } from './store';
import { initializeDB } from './db';
import LoginPage from './pages/LoginPage';
import KasirPage from './pages/KasirPage';
import GudangPage from './pages/GudangPage';
import RiwayatPage from './pages/RiwayatPage';

function App() {
  const { isAuthenticated, currentUser, activeTab, setActiveTab, logout } = useStore();

  useEffect(() => {
    initializeDB();
  }, []);

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const tabs = [
    { id: 'kasir', label: 'KASIR', icon: Layers, component: KasirPage },
    { id: 'riwayat', label: 'RIWAYAT', icon: Receipt, component: RiwayatPage },
    { id: 'gudang', label: 'GUDANG', icon: Package, component: GudangPage },
  ];

  const ActiveComponent = tabs.find(tab => tab.id === activeTab)?.component || KasirPage;

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Top Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm">
        <div>
          <h1 className="text-lg font-bold text-blue-600">MASTERPOS</h1>
          <p className="text-xs text-gray-500 uppercase">{activeTab}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm font-semibold text-gray-900">{currentUser?.username}</p>
            <p className="text-xs text-gray-500 capitalize">{currentUser?.role}</p>
          </div>
          <button
            onClick={logout}
            className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition"
            title="Logout"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <ActiveComponent />
      </div>

      {/* Bottom Navigation */}
      <div className="bg-white border-t border-gray-200 shadow-lg">
        <div className="flex items-center justify-around">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex flex-col items-center gap-1 py-3 transition ${
                  isActive
                    ? 'text-blue-600'
                    : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                <Icon className={`w-6 h-6 ${isActive ? 'scale-110' : ''}`} />
                <span className={`text-xs font-medium ${isActive ? 'font-bold' : ''}`}>
                  {tab.label}
                </span>
                {isActive && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600"></div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default App;
