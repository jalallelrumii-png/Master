import Dexie from 'dexie';

export const db = new Dexie('MasterPOS');

db.version(1).stores({
  users: '++id, username, role, &pin',
  products: '++id, barcode, name, price, stock, category',
  transactions: '++id, date, userId, total, items, paymentMethod',
  stockHistory: '++id, productId, date, type, quantity, userId, note',
  categories: '++id, name',
  settings: 'key, value'
});

// Initial data seeding
export const initializeDB = async () => {
  const userCount = await db.users.count();
  
  if (userCount === 0) {
    // Create default admin
    await db.users.add({
      username: 'Admin',
      role: 'admin',
      pin: '1234',
      createdAt: new Date()
    });

    // Create default kasir
    await db.users.add({
      username: 'Kasir',
      role: 'kasir',
      pin: '0000',
      createdAt: new Date()
    });

    // Create default categories
    await db.categories.bulkAdd([
      { name: 'Makanan' },
      { name: 'Minuman' },
      { name: 'Elektronik' },
      { name: 'Pakaian' },
      { name: 'Lainnya' }
    ]);

    // Create demo products
    await db.products.bulkAdd([
      {
        barcode: '8999909028234',
        name: 'Panci',
        price: 30000,
        stock: 28,
        category: 'Lainnya',
        createdAt: new Date()
      },
      {
        barcode: '8992761111111',
        name: 'Indomie Goreng',
        price: 3500,
        stock: 100,
        category: 'Makanan',
        createdAt: new Date()
      },
      {
        barcode: '8996001600115',
        name: 'Aqua 600ml',
        price: 4000,
        stock: 50,
        category: 'Minuman',
        createdAt: new Date()
      }
    ]);

    // Create settings
    await db.settings.bulkAdd([
      { key: 'storeName', value: 'Toko Saya' },
      { key: 'storeAddress', value: 'Jl. Contoh No. 123' },
      { key: 'storePhone', value: '081234567890' }
    ]);
  }
};

// Helper functions
export const getProductByBarcode = async (barcode) => {
  return await db.products.where('barcode').equals(barcode).first();
};

export const addTransaction = async (transaction) => {
  const id = await db.transactions.add({
    ...transaction,
    date: new Date()
  });

  // Update stock
  for (const item of transaction.items) {
    const product = await db.products.get(item.productId);
    if (product) {
      await db.products.update(item.productId, {
        stock: product.stock - item.quantity
      });

      // Add stock history
      await db.stockHistory.add({
        productId: item.productId,
        date: new Date(),
        type: 'out',
        quantity: item.quantity,
        userId: transaction.userId,
        note: `Penjualan #${id}`
      });
    }
  }

  return id;
};

export const updateProductStock = async (productId, quantity, type, userId, note) => {
  const product = await db.products.get(productId);
  if (!product) return false;

  const newStock = type === 'in' 
    ? product.stock + quantity 
    : product.stock - quantity;

  if (newStock < 0) return false;

  await db.products.update(productId, { stock: newStock });
  
  await db.stockHistory.add({
    productId,
    date: new Date(),
    type,
    quantity,
    userId,
    note
  });

  return true;
};

export default db;
