import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { LogIn, User } from 'lucide-react';
import { db } from '../db';
import { useStore } from '../store';

export default function LoginPage() {
  const { login } = useStore();
  const [selectedUser, setSelectedUser] = useState(null);
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const users = useLiveQuery(() => db.users.toArray(), []);

  const handleLogin = async () => {
    if (!selectedUser) {
      setError('Pilih user terlebih dahulu');
      return;
    }

    if (!pin) {
      setError('Masukkan PIN');
      return;
    }

    const user = users?.find(u => u.id === selectedUser.id);
    
    if (user && user.pin === pin) {
      login(user);
      setError('');
    } else {
      setError('PIN salah!');
      setPin('');
    }
  };

  const handlePinInput = (num) => {
    if (pin.length < 4) {
      setPin(pin + num);
    }
  };

  const handlePinDelete = () => {
    setPin(pin.slice(0, -1));
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-600 to-blue-800">
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="inline-block p-4 bg-white rounded-2xl shadow-lg mb-4">
              <h1 className="text-4xl font-bold text-blue-600">MASTER</h1>
              <p className="text-sm text-gray-600">POS</p>
            </div>
            <p className="text-white/90">Kasir & Inventory System</p>
          </div>

          {/* User Selection */}
          <div className="bg-white rounded-2xl shadow-xl p-6 mb-4">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Pilih User</h2>
            <div className="space-y-2">
              {users?.map((user) => (
                <button
                  key={user.id}
                  onClick={() => {
                    setSelectedUser(user);
                    setPin('');
                    setError('');
                  }}
                  className={`w-full p-4 rounded-xl flex items-center gap-3 transition ${
                    selectedUser?.id === user.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}
                >
                  <div className={`p-2 rounded-full ${
                    selectedUser?.id === user.id ? 'bg-white/20' : 'bg-gray-200'
                  }`}>
                    <User className="w-5 h-5" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-semibold">{user.username}</p>
                    <p className={`text-sm ${
                      selectedUser?.id === user.id ? 'text-white/80' : 'text-gray-500'
                    }`}>
                      {user.role === 'admin' ? 'Administrator' : 'Kasir'}
                    </p>
                  </div>
                  {selectedUser?.id === user.id && (
                    <div className="w-5 h-5 bg-white rounded-full flex items-center justify-center">
                      <div className="w-2.5 h-2.5 bg-blue-600 rounded-full"></div>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* PIN Input */}
          {selectedUser && (
            <div className="bg-white rounded-2xl shadow-xl p-6 animate-fade-in">
              <h2 className="text-lg font-bold text-gray-900 mb-4 text-center">
                Masukkan PIN
              </h2>
              
              {/* PIN Display */}
              <div className="flex justify-center gap-3 mb-6">
                {[0, 1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className={`w-14 h-14 rounded-xl flex items-center justify-center text-2xl font-bold transition ${
                      pin.length > i
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-300'
                    }`}
                  >
                    {pin.length > i ? '●' : ''}
                  </div>
                ))}
              </div>

              {/* Error Message */}
              {error && (
                <div className="mb-4 p-3 bg-red-100 border border-red-200 rounded-lg text-red-700 text-sm text-center">
                  {error}
                </div>
              )}

              {/* Number Pad */}
              <div className="grid grid-cols-3 gap-3">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                  <button
                    key={num}
                    onClick={() => handlePinInput(num.toString())}
                    className="aspect-square bg-gray-100 hover:bg-gray-200 rounded-xl text-xl font-bold text-gray-900 transition active:scale-95"
                  >
                    {num}
                  </button>
                ))}
                <button
                  onClick={handlePinDelete}
                  className="aspect-square bg-red-100 hover:bg-red-200 rounded-xl text-sm font-bold text-red-600 transition active:scale-95"
                >
                  ⌫
                </button>
                <button
                  onClick={() => handlePinInput('0')}
                  className="aspect-square bg-gray-100 hover:bg-gray-200 rounded-xl text-xl font-bold text-gray-900 transition active:scale-95"
                >
                  0
                </button>
                <button
                  onClick={handleLogin}
                  disabled={pin.length !== 4}
                  className="aspect-square bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed rounded-xl text-white transition active:scale-95 flex items-center justify-center"
                >
                  <LogIn className="w-6 h-6" />
                </button>
              </div>

              {/* Hint */}
              <p className="text-center text-xs text-gray-500 mt-4">
                Default PIN: Admin (1234), Kasir (0000)
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
