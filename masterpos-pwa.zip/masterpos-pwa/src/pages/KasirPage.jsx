import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Scanner, Search, Plus, Minus, Trash2, ShoppingCart } from 'lucide-react';
import BarcodeScanner from '../components/BarcodeScanner';
import { db, getProductByBarcode, addTransaction } from '../db';
import { useStore } from '../store';

export default function KasirPage() {
  const { cart, addToCart, updateCartQuantity, removeFromCart, clearCart, getCartTotal, currentUser } = useStore();
  const [showScanner, setShowScanner] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPayment, setShowPayment] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');

  const products = useLiveQuery(() => db.products.toArray(), []);

  const handleBarcodeScanned = async (barcode) => {
    const product = await getProductByBarcode(barcode);
    if (product) {
      if (product.stock > 0) {
        addToCart(product, 1);
      } else {
        alert('Stok habis!');
      }
    } else {
      alert('Produk tidak ditemukan!');
    }
  };

  const handleSearchProduct = async () => {
    if (!searchQuery) return;
    
    // Try to find by barcode first
    const productByBarcode = await getProductByBarcode(searchQuery);
    if (productByBarcode) {
      if (productByBarcode.stock > 0) {
        addToCart(productByBarcode, 1);
        setSearchQuery('');
      } else {
        alert('Stok habis!');
      }
      return;
    }

    // Search by name
    const productByName = products?.find(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    if (productByName) {
      if (productByName.stock > 0) {
        addToCart(productByName, 1);
        setSearchQuery('');
      } else {
        alert('Stok habis!');
      }
    } else {
      alert('Produk tidak ditemukan!');
    }
  };

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setShowPayment(true);
  };

  const handlePayment = async (method) => {
    const total = getCartTotal();
    const payment = parseInt(paymentAmount) || 0;

    if (method === 'cash' && payment < total) {
      alert('Uang tidak cukup!');
      return;
    }

    try {
      await addTransaction({
        userId: currentUser.id,
        total,
        items: cart.map(item => ({
          productId: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity
        })),
        paymentMethod: method,
        cashAmount: method === 'cash' ? payment : total,
        change: method === 'cash' ? payment - total : 0
      });

      alert('Transaksi berhasil!');
      clearCart();
      setShowPayment(false);
      setPaymentAmount('');
    } catch (error) {
      alert('Transaksi gagal: ' + error.message);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 shadow-lg">
        <h1 className="text-xl font-bold mb-3">Penjualan</h1>
        
        {/* Search Bar */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearchProduct()}
              placeholder="Cari barang atau scan..."
              className="w-full px-4 py-3 pr-10 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
            <Search className="absolute right-3 top-3.5 w-5 h-5 text-gray-400" />
          </div>
          
          <button
            onClick={() => setShowScanner(true)}
            className="bg-white text-blue-600 p-3 rounded-lg hover:bg-blue-50 transition shadow-lg"
          >
            <Scanner className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Cart Items */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {cart.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <ShoppingCart className="w-20 h-20 mb-4" />
            <p className="text-lg">Keranjang kosong</p>
            <p className="text-sm">Scan atau cari barang untuk memulai</p>
          </div>
        ) : (
          cart.map((item) => (
            <div key={item.id} className="bg-white rounded-lg p-4 shadow-sm">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{item.name}</h3>
                  <p className="text-sm text-gray-500">Stok: {item.stock}</p>
                  <p className="text-blue-600 font-bold mt-1">{formatCurrency(item.price)}</p>
                </div>
                <button
                  onClick={() => removeFromCart(item.id)}
                  className="text-red-500 p-2 hover:bg-red-50 rounded-lg transition"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 bg-gray-100 rounded-lg p-1">
                  <button
                    onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                    className="p-2 bg-white rounded-lg shadow-sm hover:bg-gray-50 transition"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="font-bold text-lg w-12 text-center">{item.quantity}</span>
                  <button
                    onClick={() => {
                      if (item.quantity < item.stock) {
                        updateCartQuantity(item.id, item.quantity + 1);
                      } else {
                        alert('Stok tidak cukup!');
                      }
                    }}
                    className="p-2 bg-white rounded-lg shadow-sm hover:bg-gray-50 transition"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500">Subtotal</p>
                  <p className="font-bold text-lg text-gray-900">
                    {formatCurrency(item.price * item.quantity)}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Bottom Action */}
      {cart.length > 0 && (
        <div className="bg-white border-t-2 border-gray-200 p-4 shadow-lg">
          <div className="flex justify-between items-center mb-3">
            <span className="text-gray-600">Total</span>
            <span className="text-2xl font-bold text-blue-600">
              {formatCurrency(getCartTotal())}
            </span>
          </div>
          <button
            onClick={handleCheckout}
            className="w-full bg-blue-600 text-white py-4 rounded-lg font-bold text-lg hover:bg-blue-700 transition shadow-lg"
          >
            BAYAR {formatCurrency(getCartTotal())}
          </button>
        </div>
      )}

      {/* Scanner Modal */}
      {showScanner && (
        <BarcodeScanner
          onScan={handleBarcodeScanned}
          onClose={() => setShowScanner(false)}
        />
      )}

      {/* Payment Modal */}
      {showPayment && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50 animate-fade-in">
          <div className="bg-white w-full rounded-t-3xl p-6 animate-slide-up">
            <h2 className="text-xl font-bold mb-4">Metode Pembayaran</h2>
            
            <div className="mb-4 p-4 bg-gray-100 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Total Bayar</span>
                <span className="text-2xl font-bold text-blue-600">
                  {formatCurrency(getCartTotal())}
                </span>
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Uang Tunai (Optional)
              </label>
              <input
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                placeholder="Masukkan jumlah uang..."
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
              />
              {paymentAmount && (
                <p className="text-sm text-gray-600 mt-2">
                  Kembalian: {formatCurrency(parseInt(paymentAmount) - getCartTotal())}
                </p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <button
                onClick={() => handlePayment('cash')}
                className="bg-green-500 text-white py-4 rounded-lg font-bold hover:bg-green-600 transition"
              >
                💵 Tunai
              </button>
              <button
                onClick={() => handlePayment('qris')}
                className="bg-purple-500 text-white py-4 rounded-lg font-bold hover:bg-purple-600 transition"
              >
                📱 QRIS
              </button>
            </div>

            <button
              onClick={() => setShowPayment(false)}
              className="w-full py-3 text-gray-600 hover:bg-gray-100 rounded-lg transition"
            >
              Batal
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
