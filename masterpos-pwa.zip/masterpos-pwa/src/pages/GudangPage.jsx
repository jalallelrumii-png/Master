import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Edit2, Trash2, Package, Scanner, TrendingUp, TrendingDown } from 'lucide-react';
import BarcodeScanner from '../components/BarcodeScanner';
import { db, updateProductStock } from '../db';
import { useStore } from '../store';

export default function GudangPage() {
  const { currentUser } = useStore();
  const [showScanner, setShowScanner] = useState(false);
  const [showStockModal, setShowStockModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [stockType, setStockType] = useState('in');
  const [stockQuantity, setStockQuantity] = useState('');
  const [stockNote, setStockNote] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const products = useLiveQuery(() => db.products.toArray(), []);
  const categories = useLiveQuery(() => db.categories.toArray(), []);

  const filteredProducts = products?.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.barcode.includes(searchQuery)
  );

  const handleBarcodeScanned = async (barcode) => {
    const product = products?.find(p => p.barcode === barcode);
    if (product) {
      setSelectedProduct(product);
      setShowStockModal(true);
    } else {
      alert('Produk tidak ditemukan!');
    }
  };

  const handleUpdateStock = async () => {
    if (!selectedProduct || !stockQuantity) {
      alert('Lengkapi data!');
      return;
    }

    const quantity = parseInt(stockQuantity);
    if (quantity <= 0) {
      alert('Jumlah harus lebih dari 0!');
      return;
    }

    const success = await updateProductStock(
      selectedProduct.id,
      quantity,
      stockType,
      currentUser.id,
      stockNote
    );

    if (success) {
      alert('Stok berhasil diupdate!');
      setShowStockModal(false);
      setSelectedProduct(null);
      setStockQuantity('');
      setStockNote('');
    } else {
      alert('Gagal update stok!');
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-xl font-bold">Gudang</h1>
          <button
            onClick={() => setShowScanner(true)}
            className="bg-white text-blue-600 p-2 rounded-lg hover:bg-blue-50 transition"
          >
            <Scanner className="w-5 h-5" />
          </button>
        </div>
        
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Cari produk..."
          className="w-full px-4 py-2 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-300"
        />
      </div>

      {/* Products List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {filteredProducts?.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <Package className="w-20 h-20 mb-4" />
            <p className="text-lg">Tidak ada produk</p>
          </div>
        ) : (
          filteredProducts?.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-lg p-4 shadow-sm"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{product.name}</h3>
                  <p className="text-sm text-gray-500">Barcode: {product.barcode}</p>
                  <p className="text-sm text-gray-500">Kategori: {product.category}</p>
                  <p className="text-blue-600 font-bold mt-1">{formatCurrency(product.price)}</p>
                  
                  <div className="mt-2 flex items-center gap-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      product.stock > 10 
                        ? 'bg-green-100 text-green-700'
                        : product.stock > 0
                        ? 'bg-yellow-100 text-yellow-700'
                        : 'bg-red-100 text-red-700'
                    }`}>
                      Sisa: {product.stock}
                    </span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setSelectedProduct(product);
                      setStockType('in');
                      setShowStockModal(true);
                    }}
                    className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition"
                    title="Tambah Stok"
                  >
                    <TrendingUp className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => {
                      setSelectedProduct(product);
                      setStockType('out');
                      setShowStockModal(true);
                    }}
                    className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition"
                    title="Kurangi Stok"
                  >
                    <TrendingDown className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Scanner Modal */}
      {showScanner && (
        <BarcodeScanner
          onScan={handleBarcodeScanned}
          onClose={() => setShowScanner(false)}
        />
      )}

      {/* Stock Update Modal */}
      {showStockModal && selectedProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50 animate-fade-in">
          <div className="bg-white w-full rounded-t-3xl p-6 animate-slide-up">
            <h2 className="text-xl font-bold mb-4">
              {stockType === 'in' ? 'Tambah Stok' : 'Kurangi Stok'}
            </h2>
            
            <div className="mb-4 p-4 bg-gray-100 rounded-lg">
              <h3 className="font-semibold">{selectedProduct.name}</h3>
              <p className="text-sm text-gray-600">Stok Saat Ini: {selectedProduct.stock}</p>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tipe Transaksi
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setStockType('in')}
                  className={`py-3 rounded-lg font-medium transition ${
                    stockType === 'in'
                      ? 'bg-green-500 text-white'
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  ➕ Masuk
                </button>
                <button
                  onClick={() => setStockType('out')}
                  className={`py-3 rounded-lg font-medium transition ${
                    stockType === 'out'
                      ? 'bg-red-500 text-white'
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  ➖ Keluar
                </button>
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Jumlah
              </label>
              <input
                type="number"
                value={stockQuantity}
                onChange={(e) => setStockQuantity(e.target.value)}
                placeholder="0"
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Catatan (Optional)
              </label>
              <textarea
                value={stockNote}
                onChange={(e) => setStockNote(e.target.value)}
                placeholder="Keterangan..."
                rows="3"
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
              />
            </div>

            {stockQuantity && (
              <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-gray-700">
                  Stok {stockType === 'in' ? 'setelah penambahan' : 'setelah pengurangan'}:{' '}
                  <span className="font-bold">
                    {stockType === 'in' 
                      ? selectedProduct.stock + parseInt(stockQuantity || 0)
                      : selectedProduct.stock - parseInt(stockQuantity || 0)
                    }
                  </span>
                </p>
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowStockModal(false);
                  setSelectedProduct(null);
                  setStockQuantity('');
                  setStockNote('');
                }}
                className="flex-1 py-3 text-gray-600 border-2 border-gray-300 rounded-lg hover:bg-gray-100 transition"
              >
                Batal
              </button>
              <button
                onClick={handleUpdateStock}
                className={`flex-1 py-3 text-white rounded-lg font-bold transition ${
                  stockType === 'in'
                    ? 'bg-green-500 hover:bg-green-600'
                    : 'bg-red-500 hover:bg-red-600'
                }`}
              >
                Simpan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
