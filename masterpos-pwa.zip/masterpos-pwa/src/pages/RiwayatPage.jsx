import { useLiveQuery } from 'dexie-react-hooks';
import { Receipt, Calendar, User, TrendingUp } from 'lucide-react';
import { db } from '../db';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

export default function RiwayatPage() {
  const transactions = useLiveQuery(
    () => db.transactions.orderBy('date').reverse().limit(50).toArray(),
    []
  );

  const users = useLiveQuery(() => db.users.toArray(), []);

  const getUserName = (userId) => {
    const user = users?.find(u => u.id === userId);
    return user?.username || 'Unknown';
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const getTodayTotal = () => {
    if (!transactions) return 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return transactions
      .filter(t => new Date(t.date) >= today)
      .reduce((sum, t) => sum + t.total, 0);
  };

  const getTodayCount = () => {
    if (!transactions) return 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return transactions.filter(t => new Date(t.date) >= today).length;
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 shadow-lg">
        <h1 className="text-xl font-bold mb-4">Riwayat Transaksi</h1>
        
        {/* Today Summary */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <div className="flex items-center gap-2 mb-1">
              <Receipt className="w-4 h-4" />
              <span className="text-xs opacity-90">Transaksi Hari Ini</span>
            </div>
            <p className="text-2xl font-bold">{getTodayCount()}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs opacity-90">Total Hari Ini</span>
            </div>
            <p className="text-lg font-bold">{formatCurrency(getTodayTotal())}</p>
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {!transactions || transactions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <Receipt className="w-20 h-20 mb-4" />
            <p className="text-lg">Belum ada transaksi</p>
          </div>
        ) : (
          transactions.map((transaction) => (
            <div key={transaction.id} className="bg-white rounded-lg p-4 shadow-sm">
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Receipt className="w-4 h-4 text-blue-600" />
                    <span className="font-bold text-gray-900">
                      #{transaction.id.toString().padStart(5, '0')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Calendar className="w-3 h-3" />
                    <span>
                      {format(new Date(transaction.date), 'dd MMM yyyy, HH:mm', { locale: id })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <User className="w-3 h-3" />
                    <span>{getUserName(transaction.userId)}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                    transaction.paymentMethod === 'cash'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-purple-100 text-purple-700'
                  }`}>
                    {transaction.paymentMethod === 'cash' ? '💵 Tunai' : '📱 QRIS'}
                  </span>
                </div>
              </div>

              {/* Items */}
              <div className="space-y-2 mb-3 pb-3 border-b border-gray-200">
                {transaction.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-sm">
                    <span className="text-gray-600">
                      {item.quantity}x {item.name}
                    </span>
                    <span className="font-medium text-gray-900">
                      {formatCurrency(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Total */}
              <div className="flex justify-between items-center">
                <span className="font-semibold text-gray-700">Total</span>
                <span className="text-xl font-bold text-blue-600">
                  {formatCurrency(transaction.total)}
                </span>
              </div>

              {/* Payment Details */}
              {transaction.paymentMethod === 'cash' && (
                <div className="mt-2 pt-2 border-t border-gray-200">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Bayar</span>
                    <span>{formatCurrency(transaction.cashAmount)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Kembalian</span>
                    <span>{formatCurrency(transaction.change)}</span>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
