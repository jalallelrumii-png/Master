import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X, Camera } from 'lucide-react';

export default function BarcodeScanner({ onScan, onClose }) {
  const scannerRef = useRef(null);
  const html5QrCodeRef = useRef(null);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    startScanner();
    
    return () => {
      stopScanner();
    };
  }, []);

  const startScanner = async () => {
    try {
      setError('');
      
      // Create scanner instance
      html5QrCodeRef.current = new Html5Qrcode("barcode-reader");
      
      // Get available cameras
      const devices = await Html5Qrcode.getCameras();
      
      if (devices && devices.length > 0) {
        // Prefer back camera on mobile
        const backCamera = devices.find(device => 
          device.label.toLowerCase().includes('back') ||
          device.label.toLowerCase().includes('rear') ||
          device.label.toLowerCase().includes('environment')
        ) || devices[0];

        // Start scanning with optimized config
        await html5QrCodeRef.current.start(
          backCamera.id,
          {
            fps: 10,
            qrbox: { width: 250, height: 150 },
            aspectRatio: 1.0,
          },
          (decodedText) => {
            // Success callback
            onScan(decodedText);
            stopScanner();
            onClose();
          },
          (errorMessage) => {
            // Error callback - just ignore, happens every frame
          }
        );
        
        setIsScanning(true);
      } else {
        setError('Tidak ada kamera ditemukan');
      }
    } catch (err) {
      console.error('Scanner error:', err);
      setError('Gagal membuka kamera. Pastikan izin kamera sudah diberikan.');
    }
  };

  const stopScanner = async () => {
    if (html5QrCodeRef.current && isScanning) {
      try {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current.clear();
        setIsScanning(false);
      } catch (err) {
        console.error('Error stopping scanner:', err);
      }
    }
  };

  const handleClose = async () => {
    await stopScanner();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/80 to-transparent p-4">
        <div className="flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <Camera className="w-6 h-6" />
            <h2 className="text-lg font-semibold">Scan Barcode</h2>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Scanner Area */}
      <div className="flex items-center justify-center h-full">
        <div id="barcode-reader" className="w-full max-w-lg"></div>
      </div>

      {/* Instructions */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
        <div className="text-center text-white">
          {error ? (
            <div className="bg-red-500/20 border border-red-500 rounded-lg p-4 mb-4">
              <p className="font-medium">{error}</p>
            </div>
          ) : (
            <>
              <div className="mb-4 p-4 bg-white/10 rounded-lg backdrop-blur-sm">
                <p className="text-sm mb-2">Arahkan kamera ke barcode</p>
                <div className="flex items-center justify-center gap-2 text-green-400">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-xs">Scanner Aktif</span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Scanning Overlay */}
      {isScanning && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <div className="relative">
            <div className="w-64 h-40 border-4 border-blue-500 rounded-lg shadow-lg shadow-blue-500/50">
              {/* Corner decorations */}
              <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-white rounded-tl-lg"></div>
              <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-white rounded-tr-lg"></div>
              <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-white rounded-bl-lg"></div>
              <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-white rounded-br-lg"></div>
              
              {/* Scanning line */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-blue-500 animate-pulse"></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
