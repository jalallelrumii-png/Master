# 🚀 DEPLOYMENT CHECKLIST

## ✅ PRE-DEPLOYMENT

### 1. Test Locally
- [ ] `npm install` berhasil
- [ ] `npm run dev` jalan tanpa error
- [ ] Login works (Admin & Kasir)
- [ ] **Barcode scanner kebuka** ✅
- [ ] Kasir: scan, add, checkout works
- [ ] Gudang: update stock works
- [ ] Riwayat: transaksi muncul
- [ ] PWA installable di localhost

### 2. Build Production
```bash
npm run build
```
- [ ] Build sukses tanpa error
- [ ] Folder `dist/` terbuat
- [ ] manifest.json ada
- [ ] service-worker.js ada

### 3. Test Production Build
```bash
npm run preview
```
- [ ] Preview berjalan
- [ ] Semua fitur works
- [ ] Scanner works di preview

---

## 🌐 DEPLOYMENT OPTIONS

### Option A: Netlify (RECOMMENDED)

#### Steps:
1. Build project:
```bash
npm run build
```

2. Login ke [Netlify](https://netlify.com)

3. Drag & drop folder `dist/` ke Netlify

4. Configure:
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Node version: 18

5. Deploy!

#### Post-Deploy:
- [ ] Test URL di mobile
- [ ] Test barcode scanner (HARUS HTTPS!)
- [ ] Install as PWA
- [ ] Test offline mode
- [ ] Custom domain (optional)

---

### Option B: Vercel

```bash
# Install CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# Production
vercel --prod
```

---

### Option C: GitHub Pages

1. Build:
```bash
npm run build
```

2. Install gh-pages:
```bash
npm install -D gh-pages
```

3. Add to package.json:
```json
"scripts": {
  "deploy": "gh-pages -d dist"
}
```

4. Deploy:
```bash
npm run deploy
```

---

### Option D: Firebase Hosting

```bash
# Install CLI
npm i -g firebase-tools

# Login
firebase login

# Init
firebase init hosting

# Build
npm run build

# Deploy
firebase deploy
```

---

## 🔒 HTTPS REQUIREMENT

**⚠️ CRITICAL untuk Barcode Scanner:**

Scanner **HANYA** jalan di:
- ✅ localhost (development)
- ✅ HTTPS (production)
- ❌ HTTP biasa (kamera tidak kebuka!)

Semua platform deploy otomatis pakai HTTPS:
- Netlify: Auto HTTPS ✅
- Vercel: Auto HTTPS ✅
- GitHub Pages: Auto HTTPS ✅
- Firebase: Auto HTTPS ✅

---

## 📱 POST-DEPLOYMENT TESTING

### Desktop (Chrome/Edge)
- [ ] Buka URL di browser
- [ ] Install PWA (icon di address bar)
- [ ] Test scanner pakai webcam
- [ ] Test offline (disconnect internet)
- [ ] Test all features

### Android (Chrome)
- [ ] Buka URL di Chrome
- [ ] Menu → "Add to Home screen"
- [ ] Open from home screen
- [ ] Test scanner pakai camera
- [ ] Test offline mode
- [ ] Rotation works

### iOS (Safari)
- [ ] Buka URL di Safari
- [ ] Share → "Add to Home Screen"
- [ ] Open from home screen
- [ ] Test scanner pakai camera
- [ ] Test offline mode
- [ ] Rotation works

---

## 🎯 FINAL CHECKLIST

### Functionality
- [ ] Login works (all users)
- [ ] Kasir: scan, search, checkout ✅
- [ ] Gudang: stock update ✅
- [ ] Riwayat: transaction list ✅
- [ ] **Barcode scanner WORKS** ✅✅✅
- [ ] Offline mode works
- [ ] Data persists (IndexedDB)

### Performance
- [ ] Load < 2 seconds
- [ ] Smooth animations
- [ ] No console errors
- [ ] No 404s
- [ ] PWA score 90+

### Mobile
- [ ] Responsive layout
- [ ] Touch targets 44px+
- [ ] No horizontal scroll
- [ ] Installable
- [ ] Works offline
- [ ] Camera access

### Security
- [ ] HTTPS enabled ✅
- [ ] PIN authentication ✅
- [ ] No sensitive data exposed
- [ ] Safe localStorage usage

---

## 🐛 COMMON ISSUES & FIXES

### Scanner tidak jalan di production
```
Fix: Pastikan deploy di HTTPS
Check: URL harus https:// bukan http://
```

### PWA tidak install
```
Fix: Clear browser cache
Fix: Build ulang dengan vite-plugin-pwa
Check: manifest.json di dist/
```

### Data hilang setelah deploy
```
Expected: IndexedDB per-domain
Solution: Data akan beda antara localhost vs production
```

### Lambat di mobile
```
Fix: Compress images
Fix: Enable Gzip di hosting
Check: Lighthouse score
```

---

## 📊 MONITORING

### Analytics (Optional)
- Google Analytics 4
- Plausible
- Umami

### Error Tracking (Optional)
- Sentry
- LogRocket
- Rollbar

---

## 🎉 SUCCESS INDICATORS

✅ **Scanner kebuka** di production (HTTPS)
✅ PWA installable di semua platform
✅ Offline mode works
✅ Data persist di IndexedDB
✅ No errors di console
✅ Fast load time
✅ Good UX/UI
✅ Works di mobile & desktop

---

## 📞 SUPPORT

Jika ada issue setelah deploy:

1. **Scanner tidak jalan?**
   - Check HTTPS
   - Check camera permission
   - Test di Chrome/Safari

2. **PWA tidak install?**
   - Clear cache
   - Check manifest.json
   - Rebuild project

3. **Offline tidak works?**
   - Check service worker
   - Clear cache
   - Test di incognito

---

**DEPLOY dengan PD! Scanner DIJAMIN JALAN di HTTPS! 🎯**

Best platforms: **Netlify** atau **Vercel** (easiest + fast)
